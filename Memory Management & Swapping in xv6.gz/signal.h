// signal.h
#define SIGINT   1
#define SIGBG    2
#define SIGFG    3
#define SIGCUSTOM 4
#define SIGP 5
