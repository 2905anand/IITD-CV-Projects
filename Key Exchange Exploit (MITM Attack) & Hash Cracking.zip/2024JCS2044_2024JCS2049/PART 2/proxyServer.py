import socket
import threading
import random
from sympy import isprime
import json

oracleServerIp = "10.237.27.193"
oracleServerPort = 5555
# oracleSocket = socket.socket()
# clientSocket = socket.socket()
host = '127.0.0.1'
port = 6666

def setupOracleServer():
    oracleSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    oracleSocket.connect((oracleServerIp, oracleServerPort))
    print(f"Connected to Oracle server at {oracleServerIp}:{oracleServerPort}")

    msg = "2024JCS2049"
    oracleSocket.sendall(msg.encode())
    receivedMessage = oracleSocket.recv(1024).decode()
    print(f"{receivedMessage}")
    primeNumber = 0
    generator = 0
    for i in range(len(receivedMessage)):
        if receivedMessage[i] == ',':
            j = i+1
            for j in range(j, len(receivedMessage)):
                generator = generator*10 + int(receivedMessage[j])
            break
        primeNumber = primeNumber*10 + int(receivedMessage[i])

    proxyServerSecretKey = random.randint(2, primeNumber-1)

    proxyServerPublicKey = pow(generator, proxyServerSecretKey, primeNumber)

    oracleSocket.sendall(str(proxyServerPublicKey).encode())

    serverPublicKey = int(oracleSocket.recv(1024).decode())

    sharedSecret = pow(serverPublicKey, proxyServerSecretKey, primeNumber)
    print(f"Oracle Server Prime Number = {primeNumber} \nOracle Server Generator = {generator} \nProxy Server(with Oracle) Secret Key = {proxyServerSecretKey} \nProxy Server(with Oracle) Public Key = {proxyServerPublicKey} \nOracle Server Public Key = {serverPublicKey} \nShared Secret(with Oracle) = {sharedSecret}")

    serverSecretKey = 0

    value = proxyServerPublicKey

    for i in range(2, primeNumber-1):

        value = (value * proxyServerPublicKey)%primeNumber
        if value == sharedSecret:
            serverSecretKey = i
            break

    CalculatedSharedSecret = pow(proxyServerPublicKey, serverSecretKey, primeNumber)
    print(f"Oracle Server Secret Key = {serverSecretKey}")

    print(f"Oracle Server Brute Force Shared Secret = {proxyServerPublicKey}^{serverSecretKey} = {CalculatedSharedSecret} {CalculatedSharedSecret == sharedSecret}\n\n")

    oracleSocket.close()

        
def setupClient():

    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.bind((host, port))
    serverSocket.listen(1)
    print(f"Listening for client on {host}:{port}")
    clientSocket, addr = serverSocket.accept()
    print(f"Client connected from {addr}")

    entryNumber = clientSocket.recv(1024).decode()

    primeNumber = generatePrime()
    generator = 3
    msg = str(primeNumber) +","+ str(generator)

    clientSocket.sendall(msg.encode())

    clientPublicKey = int(clientSocket.recv(1024).decode())

    proxyServerSecretKey = random.randint(2, 100)
    proxyServerPublicKey = pow(generator, proxyServerSecretKey, primeNumber)

    clientSocket.sendall(str(proxyServerPublicKey).encode())

    sharedSecret = pow(clientPublicKey, proxyServerSecretKey, primeNumber)

    print(f"Client Prime Number = {primeNumber} \nClient Generator = {generator} \nProxy Server(with Client) Secret Key = {proxyServerSecretKey} \nProxy Server(with Client) Public Key = {proxyServerPublicKey} \nClient Public Key = {clientPublicKey} \nShared Secret(with Client) = {sharedSecret}")

    clientSecretKey = 0

    value = proxyServerPublicKey

    for i in range(2, primeNumber-1):
        value = (value * proxyServerPublicKey)%primeNumber
        if value == sharedSecret:
            clientSecretKey = i
            break

    CalculatedSharedSecret = pow(proxyServerPublicKey, clientSecretKey, primeNumber)
    print(f"Client Secret Key = {clientSecretKey}")

    print(f"Client Brute Force Shared Secret = {proxyServerPublicKey}^{clientSecretKey} = {CalculatedSharedSecret} {CalculatedSharedSecret == sharedSecret}")

    clientSocket.close()
    serverSocket.close()


def generatePrime():
    while True:
        randomNumber = random.randint(10**12, 10**13-1)
        if isprime(randomNumber):
            return randomNumber

def main():
    # oracleServerConnect()
    # clientConnect()

    oracleThread = threading.Thread(target=setupOracleServer)
    clientThread = threading.Thread(target=setupClient)

    oracleThread.start()
    clientThread.start()

    oracleThread.join()
    clientThread.join()

    # oracleSocket.close()
    # clientSocket.close()

if __name__ == "__main__":
    main()
