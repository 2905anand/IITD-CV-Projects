import socket
import random

def main():
    serverIp = "10.237.27.193"
    serverPort = 5555

    # 1. IP: 10.194.60.51 port:5555
    # 2. IP: 10.208.66.147 port:5555

    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # print("Waiting for connection.....") 
    try:
        clientSocket.connect((serverIp, serverPort))
    except ConnectionRefusedError:
        print("Connection refused by the Oracle Server")
    # print("Waiting for connection.....")
    
    msg = "2024JCS2044"

    clientSocket.sendall(msg.encode())

    print(f"Sent Message {msg}")

    receivedMessage = clientSocket.recv(1024).decode()

    print(f"{receivedMessage}")
    primeNumber = 0
    generator = 0
    for i in range(len(receivedMessage)):
        if receivedMessage[i] == ',':
            j = i+1
            for j in range(j, len(receivedMessage)):
                generator = generator*10 + int(receivedMessage[j])
            break
        primeNumber = primeNumber*10 + int(receivedMessage[i])

    mySecretKey = random.randint(2, primeNumber-1)

    myPublicKey = pow(generator, mySecretKey, primeNumber)

    clientSocket.sendall(str(myPublicKey).encode())

    serverPublicKey = int(clientSocket.recv(1024).decode())

    sharedSecret = pow(serverPublicKey, mySecretKey, primeNumber)
    print(f"Prime Number = {primeNumber} \nGenerator = {generator} \nSecret Key = {mySecretKey} \nPublic Key = {myPublicKey} \nServer Public Key = {serverPublicKey} \nShared Secret = {sharedSecret}")

    serverSecretKey = 0

    value = myPublicKey

    for i in range(2, primeNumber-1):

        value = (value * myPublicKey)%primeNumber
        if value == sharedSecret:
            serverSecretKey = i
            break

    CalculatedSharedSecret = pow(myPublicKey, serverSecretKey, primeNumber)
    print(f"Server Secret Key = {serverSecretKey}")

    print(f"Brute Force Shared Secret = {myPublicKey}^{serverSecretKey} = {CalculatedSharedSecret} {CalculatedSharedSecret == sharedSecret}")
            
    clientSocket.close()

if __name__ == "__main__":
    main()