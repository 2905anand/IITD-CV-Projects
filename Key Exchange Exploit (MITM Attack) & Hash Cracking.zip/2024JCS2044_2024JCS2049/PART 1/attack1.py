import hashlib
import json
import time

data = []



with open("./StaticFiles/rockyou.txt", "r", encoding="utf-8", errors="ignore") as file:
    for line in file:
        data.append(line.strip())


md5_Hashes = []
with open("./StaticFiles/md5_hashes.txt", "r") as file:
    for line in file:
        md5_Hashes.append(line.strip())


sha1_Hashes = []
with open("./StaticFiles/sha1_hashes.txt", "r") as file:
    for line in file:
        sha1_Hashes.append(line.strip())

sha256_Hashes = []
with open("./StaticFiles/sha256_hashes.txt", "r") as file:
    for line in file:
        sha256_Hashes.append(line.strip())


# time calculation
start = time.time()


unhashed_password = []

for hash in md5_Hashes:
    for password in data:
        h = hashlib.md5(password.encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in MD5 is ",(end-start), "s")
start = time.time()

for hash in sha1_Hashes:
    for password in data:
        h = hashlib.sha1(password.encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in SHA1 is ",(end-start), "s")
start = time.time()

for hash in sha256_Hashes:
    for password in data:
        h = hashlib.sha256(password.encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n")

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in SHA256 is ",(end-start), "s")

with open("passwords.txt", "w") as file:
    for password in unhashed_password:
        file.write(password + "\n")


    