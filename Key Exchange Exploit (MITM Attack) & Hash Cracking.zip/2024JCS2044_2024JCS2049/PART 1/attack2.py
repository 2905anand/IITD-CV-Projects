import hashlib
import json
import time

data = []


with open("./StaticFiles/rockyou.txt", "r", encoding="utf-8", errors="ignore") as file:
    for line in file:
        data.append(line.strip())



md5_Salted_Hashes = []
with open("./StaticFiles/md5_salted_hashes.txt", "r") as file:
    for line in file:
        md5_Salted_Hashes.append(line.strip())
    

sha1_Salted_Hashes = []
with open("./StaticFiles/sha1_salted_hashes.txt", "r") as file:
    for line in file:
        sha1_Salted_Hashes.append(line.strip())

sha256_Salted_Hashes = []
with open("./StaticFiles/sha256_salted_hashes.txt", "r") as file:
    for line in file:
        sha256_Salted_Hashes.append(line.strip())


# time calculation
start = time.time()


unhashed_password = []

for hash in md5_Salted_Hashes:
    salt = hash.split(":")[0]
    hash = hash.split(":")[1]
    for password in data:
        h = hashlib.md5((password+salt).encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in MD5 is ",(end-start), "s")
start = time.time()

for hash in sha1_Salted_Hashes:
    salt = hash.split(":")[0]
    hash = hash.split(":")[1]
    for password in data:
        h = hashlib.sha1((password+salt).encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in SHA1 is ",(end-start), "s")
start = time.time()

for hash in sha256_Salted_Hashes:
    salt = hash.split(":")[0]
    hash = hash.split(":")[1]
    for password in data:
        h = hashlib.sha256((password+salt).encode()).hexdigest()
        if hash == h:
            unhashed_password.append(password)
            break

unhashed_password.append("\n")

unhashed_password.append("\n ------------------------------------------------------------ \n")
end = time.time()
print("Time taken to find the hashes's value in SHA256 is ",(end-start), "s")

with open("passwords_salted.txt", "w") as file:
    for password in unhashed_password:
        file.write(password + "\n")


    