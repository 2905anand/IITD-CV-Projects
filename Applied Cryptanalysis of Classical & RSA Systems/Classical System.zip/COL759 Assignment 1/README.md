# CRYPTANALYSIS OF VIGENERE CIPHER

### This project is implementation of Cryptanalysis of the Vigenere Cipher

#### Method Used -

-   Kasiski Method [ To predict the Key size ]
-   Index of Coincidence [ To predict and verify the Key size ]
-   Mutual Index of Coincidence [ To find out the Decryption "key" ]
-   Using given key to decrypt the Cipher text
