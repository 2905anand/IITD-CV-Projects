#!/usr/bin/python3
import socket, ssl, sys, pprint, os
    
    
def ssl_context(cadir):
	# Set up the TLS context
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.load_verify_locations(capath=cadir)
    context.verify_mode = ssl.CERT_REQUIRED
    context.check_hostname = True
    
    return context	

def task1(hostname):
    port = 443
    cadir = '/etc/ssl/certs'

    context = ssl_context(cadir)

    # Create TCP connection
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((hostname,port))
    input("After making TCP connection. Press any key to continue ...")

    # Add the TLS
    ssock = context.wrap_socket(sock, server_hostname=hostname,
                                do_handshake_on_connect=False)
    ssock.do_handshake() # start the handshake
    pprint.pprint(f"Server Certificate \n{ssock.getpeercert()}")
    print("\nCipher being Used :",end = " ")
    pprint.pprint(ssock.cipher())
    input("After handshake. Press any key to continue ...")
    
    # Close the TLS connection
    ssock.shutdown(socket.SHUT_RDWR)
    ssock.close()


def task2(hostname):
    port = 443
    cadir = './certs'

    if not os.path.exists(cadir):
        print("Folder certs did not existed so created and copied the certificates\n")
        #os.makedirs("certs")
        os.system("cp -r /etc/ssl/certs ./certs")

    context = ssl_context(cadir)

    # Create TCP connection
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((hostname,port))
    input("After making TCP connection. Press any key to continue ...")

    # Add the TLS
    ssock = context.wrap_socket(sock, server_hostname=hostname,
                                do_handshake_on_connect=False)
    ssock.do_handshake() # start the handshake
    pprint.pprint(ssock.getpeercert())
    pprint.pprint(ssock.cipher())
    input("After handshake. Press any key to continue ...")
    
    # Close the TLS connection
    ssock.shutdown(socket.SHUT_RDWR)
    ssock.close()
    

def task3(hostname):
    port = 443
    cadir = '/etc/ssl/certs'
    print("Kept context.check_hostname = TRUE.\nChange to FALSE run without hostname matching.\n")

    # Set up the TLS context
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.load_verify_locations(capath=cadir)
    context.verify_mode = ssl.CERT_REQUIRED
    context.check_hostname = False

    # Create TCP connection
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((hostname,port))
    input("After making TCP connection. Press any key to continue ...")

    # Add the TLS
    ssock = context.wrap_socket(sock, server_hostname=hostname,
                                do_handshake_on_connect=False)
    ssock.do_handshake() # start the handshake
    pprint.pprint(ssock.getpeercert())
    pprint.pprint(ssock.cipher())
    input("After handshake. Press any key to continue ...")
    
    # Close the TLS connection
    ssock.shutdown(socket.SHUT_RDWR)
    ssock.close()


def task4(hostname):
    port = 443
    cadir = '/etc/ssl/certs'
    context = ssl_context(cadir)	
	
    # Create TCP connection
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((hostname,port))
    input("After making TCP connection. Press any key to continue ...")

    # Add the TLS
    ssock = context.wrap_socket(sock, server_hostname=hostname,
                                do_handshake_on_connect=False)
    ssock.do_handshake() # start the handshake
    pprint.pprint(ssock.getpeercert())
    pprint.pprint(ssock.cipher())
    input("After handshake. Press any key to continue ...")
    
    img_path = "/images/logo-diamond.png"
    req = b"GET " + img_path.encode('utf-8') + b" HTTP/1.0\r\nHost: " + hostname.encode('utf-8') + b"\r\n\r\n"
    ssock.sendall(req)

    response = b""
    while True:
        chunk = ssock.recv(2048)
        if not chunk:
            break
        response += chunk

    header_end = response.find(b"\r\n\r\n") + 4
    image_data = response[header_end:]

    with open("downloaded.png", "wb") as f:
        f.write(image_data)

    print("Image saved.")
    
    # Close the TLS connection
    ssock.shutdown(socket.SHUT_RDWR)
    ssock.close()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Run command should be like this: python3 script.py <hostname> <task1|task2|task3|task4>")
        exit()

    hostname = sys.argv[1]
    task = sys.argv[2]

    if task == 'task1':
        task1(hostname)
    elif task == 'task2':
        task2(hostname)
    elif task == 'task3':
        task3(hostname)
    elif task == 'task4':
        task4(hostname)
    else:
        print("Invalid task. Use task1, task2, task3, or task4.")
        exit()
